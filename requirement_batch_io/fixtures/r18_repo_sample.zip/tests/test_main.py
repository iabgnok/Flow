from src.main import add
assert add(1,2)==3
